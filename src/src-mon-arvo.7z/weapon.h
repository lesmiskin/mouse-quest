#ifndef WEAPON_H
#define WEAPON_H

extern void pewGameFrame(void);
extern void pewRenderFrame(void);
extern void pewAnimateFrame(void);
extern void pew(void);

#endif