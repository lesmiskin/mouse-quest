#ifndef SCRIPTS_H
#define SCRIPTS_H

extern void scriptGameFrame(void);
extern void scriptRenderFrame(void);
extern void initScripts(void);

#endif
